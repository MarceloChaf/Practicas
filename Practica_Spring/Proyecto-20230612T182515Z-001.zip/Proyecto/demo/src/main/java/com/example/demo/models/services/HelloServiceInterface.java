package com.example.demo.models.services;

public interface HelloServiceInterface {
    String getHelloMessage();


}
